"use client";

import { useCallback } from "react";
import { loadSlim } from "tsparticles-slim";
import type { Container, Engine } from "tsparticles-engine";
import Particles from "react-tsparticles";

const ParticleBackground = () => {
  const particlesInit = useCallback(async (engine: Engine) => {
    try {
      await loadSlim(engine);
    } catch (error) {
      console.error("Error initializing particles:", error);
    }
  }, []);

  const particlesLoaded = useCallback(async (container: Container | undefined) => {
    if (container) {
      console.log("Particles container loaded");
    }
  }, []);

  return (
    <div className="absolute inset-0 -z-10">
      <Particles
        id="tsparticles"
        className="w-full h-full"
        init={particlesInit}
        loaded={particlesLoaded}
        options={{
          background: {
            color: {
              value: "transparent",
            },
          },
          fpsLimit: 30,
          interactivity: {
            detect_on: "canvas",
            events: {
              onHover: {
                enable: true,
                mode: ["attract", "connect"]
              },
              onClick: {
                enable: true,
                mode: ["push", "repulse"]
              },
              resize: true
            },
            modes: {
              attract: {
                distance: 200,
                duration: 0.8,
                factor: 3
              },
              connect: {
                distance: 150,
                links: {
                  opacity: 0.5,
                  color: "#ffffff"
                },
                radius: 100
              },
              repulse: {
                distance: 200,
                duration: 1.2
              },
              push: {
                quantity: 4
              }
            }
          },
          particles: {
            color: {
              value: "#ffffff",
              animation: {
                enable: true,
                speed: 3,
                sync: false
              }
            },
            links: {
              color: "#ffffff",
              distance: 150,
              enable: true,
              opacity: 0.7,
              width: 1,
              triangles: {
                enable: true,
                opacity: 0.2
              }
            },
            collisions: {
              enable: true,
              bounce: {
                horizontal: {
                  value: 1
                },
                vertical: {
                  value: 1
                }
              }
            },
            move: {
              enable: true,
              speed: 1.5,
              direction: "none",
              random: true,
              straight: false,
              outModes: {
                default: "bounce",
                top: "bounce",
                bottom: "bounce",
                left: "bounce",
                right: "bounce"
              },
              attract: {
                enable: true,
                rotateX: 300,
                rotateY: 600
              }
            },
            number: {
              density: {
                enable: true,
                area: 800
              },
              value: 60,
              limit: 80
            },
            opacity: {
              value: 0.8,
              animation: {
                enable: true,
                speed: 0.5,
                minimumValue: 0.4,
                sync: false
              }
            },
            shape: {
              type: ["circle", "triangle"],
              options: {
                triangle: {
                  sides: 3
                }
              }
            },
            size: {
              value: { min: 1, max: 3 },
              animation: {
                enable: true,
                speed: 1,
                minimumValue: 0.5,
                sync: false
              }
            }
          },
          detectRetina: true,
        }}
      />
    </div>
  );
};

export default ParticleBackground; 